class Constants {
  // static String baseUrl = 'http://192.168.0.100:3000/v1/';
  // static String baseUrl ='http://10.0.3.2:3000/v1/';
  static String baseUrl = 'https://api.qikpharma.com/v1/';
  // static String apiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHAiOiJxaWtQaGFybWEiLCJhcHBfdHlwZSI6Im1vYmlsZSIsImlhdCI6MTY1ODg2MTgwNiwiZXhwIjozMjM1NjYxODA2fQ.yFbI1_d-0Q6Wu5eMLz3JD0D-_wpDgx62mdtwtD4PVsw';
  static String apiKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHAiOiJxaWtQaGFybWEiLCJhcHBfdHlwZSI6IndlYiIsImlhdCI6MTcxMTYxNTE4NCwiZXhwIjozMjg4NDE1MTg0fQ.Qw_trb0Rf6fWYglOFAxzG3piBG12tORgPjnkTHfyNK8';
  static String linkToFigmaUI =
      'https://www.figma.com/file/7FoHb182Qlg4lFznZ3qswp/QikPharma-Mobile-App?node-id=0%3A1';
  static String contactSupportPageUrl = "https://qikpharma.com/#/contact-us";
  static String paystackPublicKey =
      'pk_test_8a7e1e7104ef89ba0b5761d70b96c0fcf70cf7f0';
}
