package com.ecrts.qik_pharma_mobile

import io.flutter.embedding.android.FlutterActivity

//com.ecrts.qik_pharma_mobile.MainActivity

class MainActivity: FlutterActivity() {
}
